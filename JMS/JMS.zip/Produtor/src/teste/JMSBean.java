package teste;
  
import javax.annotation.Resource;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
  
@Named(value="JMSBean")
@Dependent
public class JMSBean {
  @Resource(name="jms/CF") ConnectionFactory qcf;
  @Resource(name="jms/Quotes") Destination dest;
  static int counter;
  
  public void send () throws JMSException {
    Connection conn = null;
    try {
      conn = qcf.createConnection();
      Session session = conn.createSession(true, Session.AUTO_ACKNOWLEDGE);
      MessageProducer prod = session.createProducer(dest);
      TextMessage msg = session.createTextMessage("^BVSP = $" + (counter++));
      prod.send(msg);
    }
    
    finally {
      if (conn != null) conn.close();
    }
  }
}